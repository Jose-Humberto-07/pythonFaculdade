class Atleta:
    nome = ""
    peso = 0.0
    altura = 0.0

    def imc(peso,altura):
        return peso / altura**2