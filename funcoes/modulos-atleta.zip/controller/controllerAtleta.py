from model.atleta import *
atletas = []
atleta = Atleta();
atleta.nome = "Arinaldo"
atleta.peso = 89
atleta.altura = 1.85
atletas.append(atleta)

atleta = Atleta();
atleta.nome = "Marinaldo"
atleta.peso = 69
atleta.altura = 1.62
atletas.append(atleta)