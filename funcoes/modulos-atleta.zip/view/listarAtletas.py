from controller.controllerAtleta import *
def lista():
    for a in atletas:
        print(a.nome,"|",a.peso,"Kg | ",a.altura,"|")