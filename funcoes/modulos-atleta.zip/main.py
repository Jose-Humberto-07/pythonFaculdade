from view.listarAtletas import *
lista()